using Specflow_Example;

namespace SpecFlowProject.StepDefinitions
{
    [Binding]
    public sealed class BookServiceStepDefinitions
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly BookService _bookService = new BookService();
        private Book? _foundBook;

        public BookServiceStepDefinitions(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Given("there is a book called (.*)")]
        public void GivenThereisaBookCalled(string bookName)
        {
            var book = new Book(bookName);
            _bookService.AddBook(book);
        }

        [When("I Search for a book called (.*)")]
        public void WhenISearchForABookCalled(string bookName)
        {
            var result = _bookService.GetBook(bookName);
            _foundBook = result;
        }

        [Then("the name of the book returned should be (.*)")]
        public void ThenTheNameOfTheBookReturnedShouldBe(string bookName)
        {

            _foundBook?.Name.Should().Be(bookName);
        }
    }
}
